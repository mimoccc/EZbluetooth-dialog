package com.example.function;

import android.bluetooth.BluetoothAdapter;

public class Bluetooth {

	
	public String getMessage()
	{
		String tempString = null;
		return tempString;
		
/*		if(mBluetoothAdapter == null)
		{
			
		}*/
	}
}
