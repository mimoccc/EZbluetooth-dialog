package com.example.source;

import java.util.List;

public class Output {
	
	String user;
	String shipDate;
	String customerNumber;
	String ShiptoNumber;
	String branch;
	String disc;
	String discday;
	String netday;
	String shipToName;
	String shipToAddress;
	String shipToCity;
	String shipToState;
	String shipTozip;
	int orderTotal;
	String warehouse;
	String workOrder;
	
	List<Cargo> cargolist;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getShiptoNumber() {
		return ShiptoNumber;
	}

	public void setShiptoNumber(String shiptoNumber) {
		ShiptoNumber = shiptoNumber;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getDisc() {
		return disc;
	}

	public void setDisc(String disc) {
		this.disc = disc;
	}

	public String getDiscday() {
		return discday;
	}

	public void setDiscday(String discday) {
		this.discday = discday;
	}

	public String getNetday() {
		return netday;
	}

	public void setNetday(String netday) {
		this.netday = netday;
	}

	public String getShipToName() {
		return shipToName;
	}

	public void setShipToName(String shipToName) {
		this.shipToName = shipToName;
	}

	public String getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(String shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public String getShipToCity() {
		return shipToCity;
	}

	public void setShipToCity(String shipToCity) {
		this.shipToCity = shipToCity;
	}

	public String getShipToState() {
		return shipToState;
	}

	public void setShipToState(String shipToState) {
		this.shipToState = shipToState;
	}

	public String getShipTozip() {
		return shipTozip;
	}

	public void setShipTozip(String shipTozip) {
		this.shipTozip = shipTozip;
	}

	public int getOrderTotal() {
		return orderTotal;
	}

	public void setOrderTotal(int orderTotal) {
		this.orderTotal = orderTotal;
	}

	public String getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}

	public String getWorkOrder() {
		return workOrder;
	}

	public void setWorkOrder(String workOrder) {
		this.workOrder = workOrder;
	}

	public List<Cargo> getCargolist() {
		return cargolist;
	}

	public void setCargolist(List<Cargo> cargolist) {
		this.cargolist = cargolist;
	}
	
	
}
